import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:video_library/services/access_key_service.dart';

void main() {
  group('AccessKeyService', () {
    test('sends the key to the configured API verify endpoint', () async {
      http.Request? capturedRequest;
      final client = MockClient((request) async {
        capturedRequest = request;
        return http.Response('{"authorized":true}', 200);
      });
      final service = AccessKeyService(
        client: client,
        baseUrl: 'https://library.example.test/api',
      );
      addTearDown(service.close);

      await service.verify('test-only-key');

      expect(
        capturedRequest?.url,
        Uri.parse('https://library.example.test/api/auth/verify'),
      );
      expect(capturedRequest?.method, 'POST');
      expect(
        jsonDecode(capturedRequest!.body),
        {'accessKey': 'test-only-key'},
      );
    });

    test('shows an authentication error for a rejected key', () async {
      final service = AccessKeyService(
        client: MockClient(
          (_) async => http.Response('{"message":"denied"}', 401),
        ),
        baseUrl: 'https://library.example.test/api',
      );
      addTearDown(service.close);

      await expectLater(
        service.verify('wrong-test-key'),
        throwsA(
          isA<AccessKeyException>().having(
            (error) => error.message,
            'message',
            'That access key is not correct.',
          ),
        ),
      );
    });
  });
}
