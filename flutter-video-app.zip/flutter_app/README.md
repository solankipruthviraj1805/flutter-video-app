# Video Library (Flutter)

A Flutter source app with server-verified access-key entry, category folders, locally saved video links, and a player for direct MP4 and HLS streams. The access key is never bundled into the mobile app.

## Run

1. Install Flutter 3.27 or newer and an Android emulator/device.
2. In the Replit project, start the **API Server** workflow. It reads the `APP_ACCESS_KEY` Replit Secret when checking access.
3. Set `API_BASE_URL` to the HTTPS base URL of that API, including `/api`, then run:

   ```sh
   cd flutter_app
   flutter pub get
   flutter run --dart-define=API_BASE_URL=https://YOUR-REPLIT-DOMAIN/api
   ```

   For example, the final URL should end in `/api`; the app calls `/auth/verify`.
4. On iOS, use a Mac with Xcode to build and run the app.

## Video sources

Open a category and tap **Add video** to save a title and a direct `https://` video URL. MP4 and HLS (`.m3u8`) sources are supported by the platform video player. Video links and titles are stored on the device with SharedPreferences; the access key is not stored. Long-form streams can be scrubbed and played at normal speed, and playback time comes from the stream metadata.

The app needs a reachable API URL for access-key verification. Do not put the access key in `--dart-define`, source files, or a mobile build.
