import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/library_video.dart';
import '../models/video_category.dart';

class LibraryRepository {
  static const String _videosKey = 'saved_video_links_v1';

  Future<List<LibraryVideo>> videos() async {
    final preferences = await SharedPreferences.getInstance();
    final stored = preferences.getString(_videosKey);
    if (stored == null || stored.isEmpty) return const [];

    try {
      final decoded = jsonDecode(stored) as List<dynamic>;
      return decoded
          .whereType<Map<String, dynamic>>()
          .map(LibraryVideo.fromJson)
          .where(
              (video) => VideoCategory.all.any((c) => c.id == video.categoryId))
          .toList(growable: false);
    } on FormatException {
      return const [];
    } on TypeError {
      return const [];
    }
  }

  Future<void> addVideo(LibraryVideo video) async {
    final current = await videos();
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      _videosKey,
      jsonEncode([...current, video].map((item) => item.toJson()).toList()),
    );
  }

  Future<void> removeVideo(String videoId) async {
    final current = await videos();
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      _videosKey,
      jsonEncode(
        current
            .where((video) => video.id != videoId)
            .map((item) => item.toJson())
            .toList(),
      ),
    );
  }
}
