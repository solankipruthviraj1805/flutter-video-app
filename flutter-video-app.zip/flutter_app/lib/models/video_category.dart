import 'package:flutter/material.dart';

class VideoCategory {
  const VideoCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
  });

  final String id;
  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;

  static const List<VideoCategory> all = [
    VideoCategory(
      id: 'documentaries',
      title: 'Documentaries',
      subtitle: 'Stories worth staying for',
      color: Color(0xFFB9F36A),
      icon: Icons.public_rounded,
    ),
    VideoCategory(
      id: 'learning',
      title: 'Learning',
      subtitle: 'Ideas, explained in depth',
      color: Color(0xFF9D8BFF),
      icon: Icons.lightbulb_outline_rounded,
    ),
    VideoCategory(
      id: 'cinema',
      title: 'Cinema',
      subtitle: 'Craft, scenes, and process',
      color: Color(0xFFFF9B72),
      icon: Icons.local_movies_outlined,
    ),
    VideoCategory(
      id: 'talks',
      title: 'Talks',
      subtitle: 'Conversations and lectures',
      color: Color(0xFF78C7F5),
      icon: Icons.mic_none_rounded,
    ),
    VideoCategory(
      id: 'nature',
      title: 'Nature',
      subtitle: 'A slower look at the world',
      color: Color(0xFF75D6B5),
      icon: Icons.forest_outlined,
    ),
    VideoCategory(
      id: 'archive',
      title: 'Archive',
      subtitle: 'Saved for another time',
      color: Color(0xFFFFC76A),
      icon: Icons.bookmark_border_rounded,
    ),
  ];
}
