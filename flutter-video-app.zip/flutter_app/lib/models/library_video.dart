class LibraryVideo {
  const LibraryVideo({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.url,
    this.description = '',
  });

  final String id;
  final String categoryId;
  final String title;
  final String url;
  final String description;

  Map<String, Object?> toJson() => {
        'id': id,
        'categoryId': categoryId,
        'title': title,
        'url': url,
        'description': description,
      };

  factory LibraryVideo.fromJson(Map<String, dynamic> json) => LibraryVideo(
        id: json['id'] as String,
        categoryId: json['categoryId'] as String,
        title: json['title'] as String,
        url: json['url'] as String,
        description: json['description'] as String? ?? '',
      );
}
