import 'package:flutter/material.dart';

import 'screens/access_key_screen.dart';

class VideoLibraryApp extends StatelessWidget {
  const VideoLibraryApp({super.key});

  static const Color ink = Color(0xFF0C1017);
  static const Color panel = Color(0xFF171D27);
  static const Color accent = Color(0xFFB9F36A);

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
      surface: panel,
    );

    return MaterialApp(
      title: 'Frame Library',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: colorScheme,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: ink,
          foregroundColor: Colors.white,
          centerTitle: false,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.42)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.08)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: accent, width: 1.4),
          ),
        ),
      ),
      home: const AccessKeyScreen(),
    );
  }
}
