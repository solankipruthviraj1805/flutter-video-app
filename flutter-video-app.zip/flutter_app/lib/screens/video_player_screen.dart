import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import '../models/library_video.dart';

class VideoPlayerScreen extends StatefulWidget {
  const VideoPlayerScreen({
    required this.video,
    required this.accent,
    super.key,
  });

  final LibraryVideo video;
  final Color accent;

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final VideoPlayerController _controller;
  bool _showControls = true;
  bool _isSeeking = false;
  double _seekValue = 0;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.video.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
      }).catchError((Object _) {
        if (mounted) setState(() {});
      })
      ..addListener(_onVideoChanged);
  }

  void _onVideoChanged() {
    if (mounted && !_isSeeking) setState(() {});
  }

  @override
  void dispose() {
    _controller.removeListener(_onVideoChanged);
    _controller.dispose();
    if (_isFullscreen) {
      SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    super.dispose();
  }

  Future<void> _toggleFullscreen() async {
    final nextValue = !_isFullscreen;
    setState(() => _isFullscreen = nextValue);
    await SystemChrome.setPreferredOrientations(
      nextValue
          ? const [
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]
          : const [
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
            ],
    );
    await SystemChrome.setEnabledSystemUIMode(
      nextValue ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
  }

  Future<void> _skip(Duration amount) async {
    if (!_controller.value.isInitialized) return;
    final nextPosition = _controller.value.position + amount;
    final duration = _controller.value.duration;
    final bounded = nextPosition < Duration.zero
        ? Duration.zero
        : (nextPosition > duration ? duration : nextPosition);
    await _controller.seekTo(bounded);
  }

  String _formatDuration(Duration value) {
    final hours = value.inHours;
    final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
    return hours > 0
        ? '$hours:$minutes:$seconds'
        : '${value.inMinutes}:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final value = _controller.value;
    final isInitialized = value.isInitialized;

    return Scaffold(
      appBar: _isFullscreen
          ? null
          : AppBar(
              title: Text(
                widget.video.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
      body: SafeArea(
        top: !_isFullscreen,
        bottom: !_isFullscreen,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: isInitialized ? value.aspectRatio : 16 / 9,
                  child: GestureDetector(
                    onTap: () => setState(() => _showControls = !_showControls),
                    child: Container(
                      color: Colors.black,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          if (isInitialized)
                            VideoPlayer(_controller)
                          else if (value.hasError)
                            _PlaybackError(message: value.errorDescription)
                          else
                            const CircularProgressIndicator(),
                          if (_showControls && isInitialized)
                            _PlayerControls(
                              isPlaying: value.isPlaying,
                              accent: widget.accent,
                              isFullscreen: _isFullscreen,
                              position: _isSeeking
                                  ? Duration(milliseconds: _seekValue.round())
                                  : value.position,
                              duration: value.duration,
                              onPlayPause: () {
                                setState(() {
                                  value.isPlaying
                                      ? _controller.pause()
                                      : _controller.play();
                                });
                              },
                              onBack: () => _skip(
                                const Duration(seconds: -10),
                              ),
                              onForward: () => _skip(
                                const Duration(seconds: 10),
                              ),
                              onSeekStart: () => setState(() {
                                _isSeeking = true;
                                _seekValue =
                                    value.position.inMilliseconds.toDouble();
                              }),
                              onSeekChanged: (next) =>
                                  setState(() => _seekValue = next),
                              onSeekEnd: (next) {
                                _controller.seekTo(
                                  Duration(milliseconds: next.round()),
                                );
                                setState(() => _isSeeking = false);
                              },
                              onFullscreen: _toggleFullscreen,
                              formatDuration: _formatDuration,
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            if (!_isFullscreen)
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'NOW PLAYING',
                      style: TextStyle(
                        color: widget.accent,
                        letterSpacing: 1.6,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.video.title,
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.4,
                              ),
                    ),
                    if (widget.video.description.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        widget.video.description,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.57),
                          height: 1.5,
                        ),
                      ),
                    ],
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        Icon(
                          Icons.hd_rounded,
                          color: widget.accent,
                          size: 20,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'MP4 / HLS · ${isInitialized ? _formatDuration(value.duration) : 'Loading duration'}',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.58),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _PlayerControls extends StatelessWidget {
  const _PlayerControls({
    required this.isPlaying,
    required this.accent,
    required this.isFullscreen,
    required this.position,
    required this.duration,
    required this.onPlayPause,
    required this.onBack,
    required this.onForward,
    required this.onSeekStart,
    required this.onSeekChanged,
    required this.onSeekEnd,
    required this.onFullscreen,
    required this.formatDuration,
  });

  final bool isPlaying;
  final Color accent;
  final bool isFullscreen;
  final Duration position;
  final Duration duration;
  final VoidCallback onPlayPause;
  final VoidCallback onBack;
  final VoidCallback onForward;
  final VoidCallback onSeekStart;
  final ValueChanged<double> onSeekChanged;
  final ValueChanged<double> onSeekEnd;
  final VoidCallback onFullscreen;
  final String Function(Duration) formatDuration;

  @override
  Widget build(BuildContext context) {
    final total = duration.inMilliseconds.toDouble();
    final current =
        position.inMilliseconds.toDouble().clamp(0, total).toDouble();

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withValues(alpha: 0.35),
            Colors.transparent,
            Colors.black.withValues(alpha: 0.72),
          ],
          stops: const [0, 0.36, 1],
        ),
      ),
      child: Column(
        children: [
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                tooltip: 'Back 10 seconds',
                onPressed: onBack,
                icon: const Icon(Icons.replay_10_rounded, size: 32),
              ),
              const SizedBox(width: 18),
              IconButton.filled(
                tooltip: isPlaying ? 'Pause' : 'Play',
                onPressed: onPlayPause,
                style: IconButton.styleFrom(
                  backgroundColor: accent,
                  foregroundColor: const Color(0xFF10150C),
                ),
                iconSize: 34,
                icon: Icon(
                  isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                ),
              ),
              const SizedBox(width: 18),
              IconButton(
                tooltip: 'Forward 10 seconds',
                onPressed: onForward,
                icon: const Icon(Icons.forward_10_rounded, size: 32),
              ),
            ],
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(15, 0, 12, 9),
            child: Row(
              children: [
                Text(
                  formatDuration(position),
                  style: const TextStyle(fontSize: 11),
                ),
                Expanded(
                  child: Slider(
                    value: total <= 0 ? 0 : current,
                    min: 0,
                    max: total <= 0 ? 1 : total,
                    onChangeStart: (_) => onSeekStart(),
                    onChanged: total <= 0 ? null : onSeekChanged,
                    onChangeEnd: total <= 0 ? null : onSeekEnd,
                    activeColor: accent,
                    inactiveColor: Colors.white.withValues(alpha: 0.28),
                  ),
                ),
                Text(
                  formatDuration(duration),
                  style: const TextStyle(fontSize: 11),
                ),
                const SizedBox(width: 7),
                IconButton(
                  tooltip: isFullscreen ? 'Exit full screen' : 'Full screen',
                  onPressed: onFullscreen,
                  icon: Icon(
                    isFullscreen
                        ? Icons.fullscreen_exit_rounded
                        : Icons.fullscreen_rounded,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlaybackError extends StatelessWidget {
  const _PlaybackError({required this.message});

  final String? message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_rounded, size: 38, color: Colors.white70),
          const SizedBox(height: 13),
          const Text(
            'This video could not be played.',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          if (message != null && message!.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              message!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }
}
