import 'package:flutter/material.dart';

import '../services/access_key_service.dart';
import 'library_screen.dart';

class AccessKeyScreen extends StatefulWidget {
  const AccessKeyScreen({super.key});

  @override
  State<AccessKeyScreen> createState() => _AccessKeyScreenState();
}

class _AccessKeyScreenState extends State<AccessKeyScreen> {
  final _formKey = GlobalKey<FormState>();
  final _keyController = TextEditingController();
  final _accessKeyService = AccessKeyService();
  bool _isSubmitting = false;
  bool _hideKey = true;
  String? _errorMessage;

  @override
  void dispose() {
    _keyController.dispose();
    _accessKeyService.close();
    super.dispose();
  }

  Future<void> _continue() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    try {
      await _accessKeyService.verify(_keyController.text.trim());
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const LibraryScreen()),
      );
    } on AccessKeyException catch (error) {
      if (mounted) setState(() => _errorMessage = error.message);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(26, 36, 26, 28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        color: const Color(0xFFB9F36A),
                        borderRadius: BorderRadius.circular(19),
                      ),
                      child: const Icon(
                        Icons.play_arrow_rounded,
                        color: Color(0xFF10150C),
                        size: 38,
                      ),
                    ),
                    const SizedBox(height: 48),
                    Text(
                      'YOUR PRIVATE\\nSCREENING ROOM',
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                            color: const Color(0xFFB9F36A),
                            letterSpacing: 2.1,
                            fontWeight: FontWeight.w700,
                            height: 1.4,
                          ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'A good story\\ntakes its time.',
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                            fontWeight: FontWeight.w700,
                            height: 1.08,
                            letterSpacing: -1.4,
                          ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Enter your access key to open your video library.',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: Colors.white.withValues(alpha: 0.6),
                            height: 1.5,
                          ),
                    ),
                    const SizedBox(height: 34),
                    TextFormField(
                      controller: _keyController,
                      obscureText: _hideKey,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _continue(),
                      autofillHints: const [AutofillHints.password],
                      decoration: InputDecoration(
                        labelText: 'Access key',
                        hintText: 'Enter your key',
                        prefixIcon: const Icon(Icons.key_rounded),
                        suffixIcon: IconButton(
                          tooltip: _hideKey ? 'Show key' : 'Hide key',
                          onPressed: () => setState(() => _hideKey = !_hideKey),
                          icon: Icon(
                            _hideKey
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                      validator: (value) =>
                          value == null || value.trim().isEmpty
                              ? 'Enter your access key'
                              : null,
                    ),
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF4A2528),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          _errorMessage!,
                          style: const TextStyle(color: Color(0xFFFFC3C3)),
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: FilledButton(
                        onPressed: _isSubmitting ? null : _continue,
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFFB9F36A),
                          foregroundColor: const Color(0xFF10150C),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: _isSubmitting
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Color(0xFF10150C),
                                ),
                              )
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Open library',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                    ),
                                  ),
                                  SizedBox(width: 9),
                                  Icon(Icons.arrow_forward_rounded, size: 19),
                                ],
                              ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Center(
                      child: Text(
                        'Your key is checked securely and is not saved on this device.',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Colors.white.withValues(alpha: 0.4),
                              height: 1.5,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
