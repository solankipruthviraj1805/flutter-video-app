import 'package:flutter/material.dart';

import '../data/library_repository.dart';
import '../models/library_video.dart';
import '../models/video_category.dart';
import 'video_player_screen.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({
    required this.category,
    required this.repository,
    super.key,
  });

  final VideoCategory category;
  final LibraryRepository repository;

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  late Future<List<LibraryVideo>> _videosFuture;

  @override
  void initState() {
    super.initState();
    _loadVideos();
  }

  void _loadVideos() {
    _videosFuture = widget.repository.videos();
  }

  Future<void> _addVideo() async {
    final video = await showDialog<LibraryVideo>(
      context: context,
      builder: (_) => _AddVideoDialog(category: widget.category),
    );
    if (video == null) return;

    await widget.repository.addVideo(video);
    if (mounted) setState(_loadVideos);
  }

  Future<void> _removeVideo(LibraryVideo video) async {
    await widget.repository.removeVideo(video.id);
    if (mounted) setState(_loadVideos);
  }

  @override
  Widget build(BuildContext context) {
    final category = widget.category;
    return Scaffold(
      appBar: AppBar(
        title: Text(category.title),
        actions: [
          IconButton(
            tooltip: 'Add video',
            onPressed: _addVideo,
            icon: const Icon(Icons.add_rounded),
          ),
        ],
      ),
      body: FutureBuilder<List<LibraryVideo>>(
        future: _videosFuture,
        builder: (context, snapshot) {
          final videos = (snapshot.data ?? const <LibraryVideo>[])
              .where((video) => video.categoryId == category.id)
              .toList();

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Could not load this folder.'));
          }
          if (videos.isEmpty) {
            return _EmptyFolder(
              category: category,
              onAddVideo: _addVideo,
            );
          }

          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 8, 22, 24),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: category.color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Icon(category.icon, color: category.color),
                      ),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Text(
                          '${videos.length} ${videos.length == 1 ? 'video' : 'videos'} · ${category.subtitle}',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Colors.white.withValues(alpha: 0.57),
                                  ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 0, 22, 32),
                sliver: SliverList.separated(
                  itemCount: videos.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 13),
                  itemBuilder: (context, index) {
                    final video = videos[index];
                    return _VideoTile(
                      video: video,
                      accent: category.color,
                      onTap: () => Navigator.of(context).push<void>(
                        MaterialPageRoute<void>(
                          builder: (_) => VideoPlayerScreen(
                            video: video,
                            accent: category.color,
                          ),
                        ),
                      ),
                      onDelete: () => _removeVideo(video),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addVideo,
        backgroundColor: category.color,
        foregroundColor: const Color(0xFF10150C),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add video'),
      ),
    );
  }
}

class _EmptyFolder extends StatelessWidget {
  const _EmptyFolder({
    required this.category,
    required this.onAddVideo,
  });

  final VideoCategory category;
  final VoidCallback onAddVideo;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(category.icon, size: 43, color: category.color),
            const SizedBox(height: 18),
            Text(
              'This folder is ready.',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Add an MP4 or HLS link to start watching.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white.withValues(alpha: 0.55)),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: onAddVideo,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Add your first video'),
            ),
          ],
        ),
      ),
    );
  }
}

class _VideoTile extends StatelessWidget {
  const _VideoTile({
    required this.video,
    required this.accent,
    required this.onTap,
    required this.onDelete,
  });

  final LibraryVideo video;
  final Color accent;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF171D27),
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              Container(
                width: 92,
                height: 72,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.movie_outlined, color: accent, size: 30),
                    Positioned(
                      right: 7,
                      bottom: 6,
                      child: Icon(
                        Icons.play_circle_fill_rounded,
                        color: Colors.white.withValues(alpha: 0.9),
                        size: 20,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      video.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      video.url.toLowerCase().contains('.m3u8')
                          ? 'HLS STREAM'
                          : 'VIDEO LINK',
                      style: TextStyle(
                        color: accent,
                        fontSize: 10,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                tooltip: 'Video options',
                onSelected: (value) {
                  if (value == 'delete') onDelete();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('Remove from folder'),
                  ),
                ],
                icon: Icon(
                  Icons.more_vert_rounded,
                  color: Colors.white.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AddVideoDialog extends StatefulWidget {
  const _AddVideoDialog({required this.category});

  final VideoCategory category;

  @override
  State<_AddVideoDialog> createState() => _AddVideoDialogState();
}

class _AddVideoDialogState extends State<_AddVideoDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _urlController = TextEditingController();

  @override
  void dispose() {
    _titleController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.of(context).pop(
      LibraryVideo(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        categoryId: widget.category.id,
        title: _titleController.text.trim(),
        url: _urlController.text.trim(),
      ),
    );
  }

  String? _validateUrl(String? value) {
    if (value == null || value.trim().isEmpty) return 'Enter a video URL';
    final uri = Uri.tryParse(value.trim());
    if (uri == null || !uri.hasAuthority || uri.scheme != 'https') {
      return 'Use a secure HTTPS video URL';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add a video'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _titleController,
              autofocus: true,
              maxLength: 80,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Title',
                hintText: 'e.g. The quiet coast',
              ),
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'Add a title' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _urlController,
              keyboardType: TextInputType.url,
              autocorrect: false,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Video URL',
                hintText: 'https://… (MP4 or HLS)',
                alignLabelWithHint: true,
              ),
              validator: _validateUrl,
            ),
            const SizedBox(height: 10),
            Text(
              'This link stays on this device. Long videos work best from a stable direct MP4 or HLS stream.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.white.withValues(alpha: 0.55),
                  ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _save,
          style: FilledButton.styleFrom(
            backgroundColor: widget.category.color,
            foregroundColor: const Color(0xFF10150C),
          ),
          child: const Text('Save video'),
        ),
      ],
    );
  }
}
