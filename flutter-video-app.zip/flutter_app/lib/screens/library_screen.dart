import 'package:flutter/material.dart';

import '../data/library_repository.dart';
import '../models/library_video.dart';
import '../models/video_category.dart';
import 'access_key_screen.dart';
import 'category_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _repository = LibraryRepository();
  late Future<List<LibraryVideo>> _videosFuture;
  String _search = '';

  @override
  void initState() {
    super.initState();
    _videosFuture = _repository.videos();
  }

  Future<void> _refresh() async {
    setState(() => _videosFuture = _repository.videos());
    await _videosFuture;
  }

  @override
  Widget build(BuildContext context) {
    final visibleCategories = VideoCategory.all.where((category) {
      final query = _search.toLowerCase();
      return category.title.toLowerCase().contains(query) ||
          category.subtitle.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'FRAME / LIBRARY',
          style: TextStyle(
            fontSize: 13,
            letterSpacing: 2,
            fontWeight: FontWeight.w800,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Lock library',
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute<void>(
                builder: (_) => const AccessKeyScreen(),
              ),
              (_) => false,
            ),
            icon: const Icon(Icons.lock_outline_rounded),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: RefreshIndicator(
          onRefresh: _refresh,
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 16, 22, 22),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Take your time.',
                        style:
                            Theme.of(context).textTheme.headlineLarge?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: -1,
                                ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'A collection of stories, all in one place.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white.withValues(alpha: 0.56),
                            ),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        onChanged: (value) => setState(() => _search = value),
                        decoration: const InputDecoration(
                          hintText: 'Find a folder',
                          prefixIcon: Icon(Icons.search_rounded),
                        ),
                      ),
                      const SizedBox(height: 26),
                      Row(
                        children: [
                          Text(
                            'YOUR FOLDERS',
                            style: Theme.of(context)
                                .textTheme
                                .labelMedium
                                ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.48),
                                  letterSpacing: 1.6,
                                  fontWeight: FontWeight.w700,
                                ),
                          ),
                          const Spacer(),
                          Text(
                            '${visibleCategories.length.toString().padLeft(2, '0')} folders',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.42),
                                ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              FutureBuilder<List<LibraryVideo>>(
                future: _videosFuture,
                builder: (context, snapshot) {
                  final videos = snapshot.data ?? const <LibraryVideo>[];
                  if (snapshot.hasError) {
                    return const SliverFillRemaining(
                      hasScrollBody: false,
                      child: Center(
                        child: Text('Could not load your saved videos.'),
                      ),
                    );
                  }

                  return SliverPadding(
                    padding: const EdgeInsets.fromLTRB(22, 0, 22, 34),
                    sliver: SliverList.separated(
                      itemCount: visibleCategories.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final category = visibleCategories[index];
                        final count = videos
                            .where((video) => video.categoryId == category.id)
                            .length;
                        return _CategoryFolder(
                          category: category,
                          videoCount: count,
                          onTap: () async {
                            await Navigator.of(context).push<void>(
                              MaterialPageRoute<void>(
                                builder: (_) => CategoryScreen(
                                  category: category,
                                  repository: _repository,
                                ),
                              ),
                            );
                            await _refresh();
                          },
                        );
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryFolder extends StatelessWidget {
  const _CategoryFolder({
    required this.category,
    required this.videoCount,
    required this.onTap,
  });

  final VideoCategory category;
  final int videoCount;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF171D27),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: category.color.withValues(alpha: 0.13),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(category.icon, color: category.color, size: 26),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category.title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      category.subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white.withValues(alpha: 0.52),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Icon(Icons.folder_rounded, color: category.color, size: 19),
                  const SizedBox(height: 6),
                  Text(
                    '$videoCount ${videoCount == 1 ? 'video' : 'videos'}',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.46),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 7),
              Icon(
                Icons.chevron_right_rounded,
                color: Colors.white.withValues(alpha: 0.35),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
