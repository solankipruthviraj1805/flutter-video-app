import 'dart:convert';

import 'package:http/http.dart' as http;

class AccessKeyException implements Exception {
  const AccessKeyException(this.message);

  final String message;

  @override
  String toString() => message;
}

class AccessKeyService {
  AccessKeyService({http.Client? client, String? baseUrl})
      : _client = client ?? http.Client(),
        _apiBaseUrl = baseUrl ?? _configuredApiBaseUrl;

  static const String _configuredApiBaseUrl =
      String.fromEnvironment('API_BASE_URL', defaultValue: '');

  final http.Client _client;
  final String _apiBaseUrl;

  Future<void> verify(String accessKey) async {
    if (_apiBaseUrl.isEmpty) {
      throw const AccessKeyException(
        'The app needs an API URL. Set API_BASE_URL and restart the app.',
      );
    }

    final base = Uri.tryParse(_apiBaseUrl);
    final localHttpHosts = {'localhost', '127.0.0.1', '10.0.2.2'};
    final isSecure = base?.scheme == 'https' ||
        (base?.scheme == 'http' && localHttpHosts.contains(base?.host));
    if (base == null || !base.hasScheme || !base.hasAuthority || !isSecure) {
      throw const AccessKeyException(
        'The API URL must use HTTPS. Local emulator URLs may use HTTP.',
      );
    }

    final basePath = base.path.endsWith('/') ? base.path : '${base.path}/';
    final endpoint = base.replace(path: basePath).resolve('auth/verify');

    late final http.Response response;
    try {
      response = await _client
          .post(
            endpoint,
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'accessKey': accessKey}),
          )
          .timeout(const Duration(seconds: 15));
    } on Exception {
      throw const AccessKeyException(
        'Could not reach the library. Check your connection and try again.',
      );
    }

    if (response.statusCode == 200) return;

    if (response.statusCode == 401) {
      throw const AccessKeyException('That access key is not correct.');
    }
    if (response.statusCode == 503) {
      throw const AccessKeyException(
        'Access verification is temporarily unavailable.',
      );
    }
    throw AccessKeyException(
      response.statusCode == 400
          ? 'Enter an access key to continue.'
          : 'Could not verify the access key (${response.statusCode}).',
    );
  }

  void close() => _client.close();
}
